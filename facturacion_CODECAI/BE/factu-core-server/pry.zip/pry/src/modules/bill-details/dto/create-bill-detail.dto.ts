export class CreateBillDetailDto {
    id: number;
    name: string;
    amount: number;
    description: string;
    itemPrice: number;
    totalItem: number;
    billId: number;
}
