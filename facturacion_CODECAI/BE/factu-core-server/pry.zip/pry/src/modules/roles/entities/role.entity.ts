import {User} from '../../users/entities/user.entity';

export class Role{
    name: string;
    users?: User[]; 
}